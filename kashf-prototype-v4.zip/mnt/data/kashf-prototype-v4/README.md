# Kashf Prototype v4 — Manual Data Lab

Local-only browser prototype for testing Kashf's financial logic without SIMAH, SAMA, Open Banking, or bank integrations.

## Included
- Manual credit profile
- Manual loans and cards
- Manual financial profile
- Transparent calculation engine
- Kashf Health (separate from entered credit score)
- Next Best Action recommendations
- Debt Buyout Optimizer
- What-if Simulator
- 30/60/90 day plan
- Recommendation validation mode
- Local Storage persistence
- Delete-all-data control
- Demo data mode

## Privacy
No external APIs are used. Data remains in the browser's Local Storage unless the user deletes it.

## Future migration
Recommended production migration path: Next.js + TypeScript + validated domain models + secure backend + consent management + regulated integrations.
